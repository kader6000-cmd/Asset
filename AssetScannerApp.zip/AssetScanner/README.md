# Asset Scanner

تطبيق Android للبحث عن الأصول داخل ملف Excel بصورة الملصق (OCR) أو بالرقم.

- البحث: `Inventory Number` أو `Main No.` (+ `Sub#` اختياري) — أول نتيجة، كما في النسخة الأصلية.
- قراءة الصورة: ML Kit (تعمل بدون إنترنت).
- اختيار/تغيير ملف الأصول من داخل التطبيق (.xlsx).

## بناء الـ APK على GitHub (بدون Android Studio)
1. ارفع محتويات هذا المجلد إلى مستودع جديد على GitHub (الفرع `main`).
2. افتح تبويب **Actions** ← سيعمل workflow باسم **Build APK** تلقائياً.
3. بعد انتهائه (~5 دقائق) نزّل الملف من **Artifacts** ← `AssetScanner-apk`.

## البناء محلياً
افتح المجلد في Android Studio ثم Build ▸ Build APK(s).
