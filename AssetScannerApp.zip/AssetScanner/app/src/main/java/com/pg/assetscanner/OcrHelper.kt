package com.pg.assetscanner

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object OcrHelper {

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    // نفس تعبير التطبيق الأصلي
    private val ORIGINAL = Regex("\\b\\d{9,15}(-\\d+)?\\b")

    suspend fun recognize(context: Context, uri: Uri): String =
        suspendCancellableCoroutine { cont ->
            try {
                val image = InputImage.fromFilePath(context, uri)
                recognizer.process(image)
                    .addOnSuccessListener { cont.resume(it.text) }
                    .addOnFailureListener { cont.resumeWithException(it) }
            } catch (e: Exception) {
                cont.resumeWithException(e)
            }
        }

    /**
     * 1) نفس التعبير الأصلي (مع توحيد المسافات حول الشرطة فقط).
     * 2) فقط إن لم يجد شيئاً: تصحيح الحروف المشابهة للأرقام (O→0, I→1) كمحاولة احتياطية.
     */
    fun extractNumber(text: String): String? {
        val normalized = text.replace(Regex("\\s*[-–—]\\s*"), "-")
        ORIGINAL.find(normalized)?.let { return it.value }

        val tolerant = Regex("[0-9OoQDIl]{9,15}(?:-[0-9OoIl]{1,3})?")
        for (m in tolerant.findAll(normalized)) {
            val v = m.value
            if (v.count { it.isDigit() } < 6) continue
            val fixed = buildString {
                for (ch in v) append(
                    when (ch) {
                        'O', 'o', 'Q', 'D' -> '0'
                        'I', 'l' -> '1'
                        else -> ch
                    }
                )
            }
            if (ORIGINAL.matches(fixed)) return fixed
        }
        return null
    }
}
