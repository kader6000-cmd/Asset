package com.pg.assetscanner

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object C {
    val Bg = Color(0xFF0A1020)
    val Bg2 = Color(0xFF101B3B)
    val Card = Color(0xFF17233F)
    val CardHi = Color(0xFF1D2B4D)
    val Cyan = Color(0xFF22D3EE)
    val Blue = Color(0xFF3B82F6)
    val Violet = Color(0xFF8B5CF6)
    val Pink = Color(0xFFEC4899)
    val Amber = Color(0xFFFBBF24)
    val Green = Color(0xFF34D399)
    val Text = Color(0xFFE8EEF9)
    val Dim = Color(0xFF93A4C3)
    val Danger = Color(0xFFF87171)
}

@Composable
fun AssetTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Cyan, onPrimary = C.Bg, secondary = C.Violet,
            background = C.Bg, surface = C.Card, onSurface = C.Text, onBackground = C.Text
        ),
        content = content
    )
}

/** شاشات القائمة الجانبية. */
private enum class DrawerScreen { Home, Recent, File, About }

@Composable
fun AppRoot(vm: MainViewModel, onPickFile: () -> Unit, onCamera: () -> Unit, onGallery: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val drawerState = rememberDrawerState(DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        var screen by remember { mutableStateOf(DrawerScreen.Home) }
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = C.Bg2, drawerContentColor = C.Text) {
                    DrawerContent(
                        current = screen,
                        onSelect = { screen = it; scope.launch { drawerState.close() } }
                    )
                }
            }
        ) {
            Surface(Modifier.fillMaxSize(), color = C.Bg, contentColor = C.Text) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(C.Bg, C.Bg2)))
                        .systemBarsPadding()
                ) {
                    val r = vm.result
                    if (r != null) {
                        BackHandler { vm.closeResult() }
                        ResultScreen(r, onBack = { vm.closeResult() })
                    } else {
                        when (screen) {
                            DrawerScreen.Home -> HomeScreen(vm, onPickFile, onCamera, onGallery, onMenu = { scope.launch { drawerState.open() } })
                            DrawerScreen.Recent -> RecentScreen(vm, onMenu = { scope.launch { drawerState.open() } }, onSearch = { q -> screen = DrawerScreen.Home; vm.performSearch(q) })
                            DrawerScreen.File -> FileScreen(vm, onPickFile, onMenu = { scope.launch { drawerState.open() } })
                            DrawerScreen.About -> AboutScreen(onMenu = { scope.launch { drawerState.open() } })
                        }
                    }
                    if (vm.busy) BusyOverlay(vm.busyText)
                }
            }
        }
    }
}

/** يُظهر العنصر بحركة دخول متدرجة. */
@Composable
fun Reveal(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 70L); visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(380)) + slideInVertically(tween(380)) { it / 5 }
    ) { content() }
}

// ============================ الشاشة الرئيسية ============================

@Composable
fun HomeScreen(vm: MainViewModel, onPickFile: () -> Unit, onCamera: () -> Unit, onGallery: () -> Unit, onMenu: () -> Unit) {
    val focus = LocalFocusManager.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header(onMenu) }
        item { FileCard(vm, onPickFile) }

        if (vm.hasFile) {
            item { ScanActions(onCamera, onGallery) }
            item { SearchCard(vm, focus) }
        }

        val msg = vm.message
        if (msg != null) item { Banner("⚠️", msg, C.Danger) }
        val nf = vm.notFound
        if (nf != null) item { Banner("🔎", "الأصل ($nf) غير موجود في الشيت", C.Amber) }

        if (vm.hasFile && vm.recent.isNotEmpty()) {
            item {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("آخر عمليات البحث", color = C.Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { vm.clearRecent() }) { Text("مسح", fontSize = 12.sp, color = C.Dim) }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(vm.recent.toList()) { q -> RecentChip(q) { vm.performSearch(q) } }
                    }
                }
            }
        }
        if (vm.hasFile) {
            item {
                Text(
                    "💡 قرّب الكاميرا من الملصق بحيث يظهر الرقم واضحاً ومضاءً جيداً",
                    color = C.Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun Header(onMenu: () -> Unit) {
    Row(Modifier.padding(top = 8.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(C.CardHi)
                .clickable(onClick = onMenu),
            contentAlignment = Alignment.Center
        ) { Text("☰", fontSize = 20.sp, color = C.Text) }
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(C.Cyan, C.Violet))),
            contentAlignment = Alignment.Center
        ) { Text("🏷️", fontSize = 26.sp) }
        Spacer(Modifier.width(14.dp))
        Column {
            Text("Asset Scanner", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = C.Text)
            Text("ابحث عن أي أصل بالتصوير أو بالرقم", fontSize = 13.sp, color = C.Dim)
        }
    }
}

@Composable
fun FileCard(vm: MainViewModel, onPickFile: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1C2D5A), Color(0xFF16213F))))
            .padding(16.dp)
    ) {
        if (vm.hasFile) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(C.Green.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Text("📗", fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("الملف النشط", fontSize = 11.sp, color = C.Dim)
                    Text(vm.fileName.ifBlank { "assets.xlsx" }, fontWeight = FontWeight.Bold, color = C.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (vm.statusText.isNotBlank()) Text(vm.statusText, fontSize = 12.sp, color = C.Green)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onPickFile,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) { Text("تغيير ملف الأصول (Excel)", fontWeight = FontWeight.Bold) }
        } else {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("📊", fontSize = 42.sp)
                Spacer(Modifier.height(6.dp))
                Text("يرجى اختيار ملف الإكسل (.xlsx) للبدء", fontWeight = FontWeight.Bold, color = C.Text, textAlign = TextAlign.Center)
                Text("الملف الذي يحتوي على سجل الأصول", fontSize = 12.sp, color = C.Dim)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onPickFile,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("اختيار ملف الإكسل", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun ScanActions(onCamera: () -> Unit, onGallery: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ActionTile("📷", "تصوير الملصق", "Camera", C.Cyan, C.Blue, Modifier.weight(1f), onCamera)
        ActionTile("🖼️", "من المعرض", "Gallery", C.Violet, C.Pink, Modifier.weight(1f), onGallery)
    }
}

@Composable
fun ActionTile(icon: String, title: String, sub: String, c1: Color, c2: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(c1, c2)))
            .clickable(onClick = onClick)
            .padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 34.sp)
        Spacer(Modifier.height(6.dp))
        Text(title, fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 15.sp)
        Text(sub, color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
    }
}

@Composable
fun SearchCard(vm: MainViewModel, focus: FocusManager) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(C.Card)
            .padding(14.dp)
    ) {
        Text("أو اكتب رقم الأصل", color = C.Dim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            textStyle = TextStyle(
                fontFamily = FontFamily.Monospace, fontSize = 18.sp,
                fontWeight = FontWeight.Bold, textDirection = TextDirection.Ltr
            ),
            placeholder = { Text("200000131051-0", fontFamily = FontFamily.Monospace, color = C.Dim) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus(); vm.performSearch() }),
            trailingIcon = {
                if (vm.query.isNotEmpty()) TextButton(onClick = { vm.query = "" }) { Text("✕", color = C.Dim) }
            }
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { focus.clearFocus(); vm.performSearch() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = C.Amber, contentColor = C.Bg)
        ) { Text("🔍  بحث", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
    }
}

@Composable
fun Banner(icon: String, text: String, color: Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(color.copy(alpha = 0.14f))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun RecentChip(q: String, onClick: () -> Unit) {
    Text(
        q,
        Modifier
            .clip(RoundedCornerShape(50))
            .background(C.CardHi)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        color = C.Text, fontFamily = FontFamily.Monospace, fontSize = 13.sp
    )
}

// ============================ صفحة النتيجة ============================

private fun assetAsText(a: AssetModel): String = buildString {
    appendLine("Main No.: ${a.mainNo}")
    appendLine("Sub#: ${a.subNo}")
    appendLine("Asset Description: ${a.description}")
    if (a.secondLineDesc.isNotBlank()) appendLine("2nd Line Asset Desc: ${a.secondLineDesc}")
    appendLine("Qty: ${a.qty}")
    appendLine("A.Class: ${a.assetClass}")
    appendLine("Cost Center: ${a.costCenter}")
    appendLine("Location: ${a.location}")
    appendLine("Room: ${a.room}")
    appendLine("Inventory Number: ${a.inventoryNumber}")
    append("Last Inv.: ${a.lastInv}")
}

@Composable
fun ResultScreen(a: AssetModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("→  رجوع", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.weight(1f))
            Text("بيانات الأصل", color = C.Dim, fontSize = 13.sp)
            Spacer(Modifier.width(12.dp))
        }

        // بيانات إنجليزية من الشيت → اتجاه من اليسار لليمين داخل البطاقات
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Reveal(0) { HeroCard(a) }

                Reveal(1) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Classification", C.Amber)
                        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatTile("A.Class", a.assetClass, C.Amber, Modifier.weight(1.3f).fillMaxHeight())
                            StatTile("Cost Center", a.costCenter, C.Green, Modifier.weight(1.3f).fillMaxHeight())
                            StatTile("Qty", a.qty, C.Cyan, Modifier.weight(0.8f).fillMaxHeight())
                        }
                    }
                }

                Reveal(2) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Where is it?", C.Cyan)
                        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            InfoTile("📍", "Location", a.location, C.Cyan, Modifier.weight(1f).fillMaxHeight())
                            InfoTile("🚪", "Room", a.room, C.Pink, Modifier.weight(1f).fillMaxHeight())
                        }
                    }
                }

                Reveal(3) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Inventory", C.Violet)
                        InfoTile("🔢", "Inventory Number", a.inventoryNumber, C.Violet, Modifier.fillMaxWidth(), mono = true, big = true)
                        InfoTile("📅", "Last Inv.", a.lastInv, C.Amber, Modifier.fillMaxWidth(), big = true)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onBack,
                modifier = Modifier.weight(1f).height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = C.Amber, contentColor = C.Bg)
            ) { Text("🔍  بحث جديد", fontWeight = FontWeight.ExtraBold) }
            OutlinedButton(
                onClick = {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, assetAsText(a))
                    }
                    ctx.startActivity(Intent.createChooser(i, "مشاركة بيانات الأصل"))
                },
                modifier = Modifier.height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("↗ مشاركة", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun SectionTitle(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).clip(RoundedCornerShape(2.dp)).background(color))
        Spacer(Modifier.width(8.dp))
        Text(text.uppercase(), color = C.Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    }
}

@Composable
fun HeroCard(a: AssetModel) {
    val tagged = a.inventoryNumber.isNotBlank() && !a.inventoryNumber.contains("NO TAG", ignoreCase = true) &&
        !a.inventoryNumber.contains("UNTAGGABLE", ignoreCase = true)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF0EA5E9), Color(0xFF5B21B6), Color(0xFFBE185D))))
            .drawBehind {
                drawCircle(Color.White.copy(alpha = 0.08f), radius = size.width * 0.42f, center = Offset(size.width * 0.98f, 0f))
                drawCircle(Color.White.copy(alpha = 0.06f), radius = size.width * 0.28f, center = Offset(0f, size.height))
            }
            .padding(20.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("FIXED ASSET", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Spacer(Modifier.weight(1f))
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.28f)).padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (tagged) C.Green else C.Amber))
                    Spacer(Modifier.width(6.dp))
                    Text(if (tagged) "TAGGED" else "NO TAG", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Main No.", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
            Text(a.mainNo, color = Color.White, fontSize = 32.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.22f)).padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Sub#", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                Spacer(Modifier.width(10.dp))
                Text(a.subNo.ifBlank { "0" }, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.25f)))
            Spacer(Modifier.height(14.dp))
            Text("Asset Description", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
            Text(a.description.ifBlank { "—" }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 26.sp)
            if (a.secondLineDesc.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(a.secondLineDesc, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun copyValue(label: String, value: String): () -> Unit {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    return {
        if (value.isNotBlank()) {
            clip.setText(AnnotatedString(value))
            Toast.makeText(ctx, "تم نسخ $label", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun StatTile(label: String, value: String, accent: Color, modifier: Modifier) {
    val onCopy = copyValue(label, value)
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(C.Card)
            .clickable(onClick = onCopy)
            .padding(14.dp)
    ) {
        Box(Modifier.width(26.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(accent))
        Spacer(Modifier.height(10.dp))
        Text(label, color = C.Dim, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(value.ifBlank { "—" }, color = if (value.isBlank()) C.Dim else C.Text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun InfoTile(icon: String, label: String, value: String, accent: Color, modifier: Modifier, mono: Boolean = false, big: Boolean = false) {
    val onCopy = copyValue(label, value)
    Row(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(C.Card)
            .clickable(onClick = onCopy)
            .height(IntrinsicSize.Min)
    ) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(accent))
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) { Text(icon, fontSize = 20.sp) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(label, color = C.Dim, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(
                    value.ifBlank { "—" },
                    color = if (value.isBlank()) C.Dim else C.Text,
                    fontSize = if (big) 19.sp else 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default
                )
            }
        }
    }
}

@Composable
fun BusyOverlay(text: String) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.clip(RoundedCornerShape(22.dp)).background(C.Card).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(color = C.Cyan)
            Spacer(Modifier.height(14.dp))
            Text(text, color = C.Text, textAlign = TextAlign.Center)
        }
    }
}

// ============================ القائمة الجانبية ============================

@Composable
fun DrawerContent(current: DrawerScreen, onSelect: (DrawerScreen) -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(C.Cyan, C.Violet)))
                .padding(18.dp)
        ) {
            Column {
                Text("🏷️", fontSize = 30.sp)
                Spacer(Modifier.height(8.dp))
                Text("Asset Scanner", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Abdelkader Ahmed", fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
            }
        }
        Spacer(Modifier.height(14.dp))
        DrawerItem("🏠", "الرئيسية", DrawerScreen.Home, current, onSelect)
        DrawerItem("🕘", "آخر عمليات البحث", DrawerScreen.Recent, current, onSelect)
        DrawerItem("📊", "ملف الأصول", DrawerScreen.File, current, onSelect)
        DrawerItem("ℹ️", "حول التطبيق", DrawerScreen.About, current, onSelect)
        Spacer(Modifier.weight(1f))
        Text("الإصدار 1.0", color = C.Dim, fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp, bottom = 8.dp))
    }
}

@Composable
fun DrawerItem(icon: String, label: String, target: DrawerScreen, current: DrawerScreen, onSelect: (DrawerScreen) -> Unit) {
    NavigationDrawerItem(
        label = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 18.sp)
                Spacer(Modifier.width(12.dp))
                Text(label, fontSize = 15.sp, fontWeight = if (target == current) FontWeight.Bold else FontWeight.Normal)
            }
        },
        selected = target == current,
        onClick = { onSelect(target) },
        modifier = Modifier.padding(vertical = 2.dp),
        shape = RoundedCornerShape(14.dp),
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = C.Cyan.copy(alpha = 0.18f),
            selectedTextColor = C.Cyan,
            unselectedTextColor = C.Text,
            unselectedContainerColor = Color.Transparent
        )
    )
}

@Composable
fun DrawerTopBar(title: String, onMenu: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(C.CardHi)
                .clickable(onClick = onMenu),
            contentAlignment = Alignment.Center
        ) { Text("☰", fontSize = 20.sp, color = C.Text) }
        Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = C.Text)
    }
}

@Composable
fun RecentScreen(vm: MainViewModel, onMenu: () -> Unit, onSearch: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        DrawerTopBar("آخر عمليات البحث", onMenu)
        Spacer(Modifier.height(12.dp))
        if (vm.recent.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد عمليات بحث بعد", color = C.Dim, fontSize = 14.sp)
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${vm.recent.size} عملية بحث", color = C.Dim, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { vm.clearRecent() }) { Text("مسح الكل", fontSize = 12.sp, color = C.Danger) }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.recent.toList()) { q ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(C.Card)
                            .clickable { onSearch(q) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔎", fontSize = 18.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(q, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = C.Text)
                    }
                }
            }
        }
    }
}

@Composable
fun FileScreen(vm: MainViewModel, onPickFile: () -> Unit, onMenu: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        DrawerTopBar("ملف الأصول", onMenu)
        Spacer(Modifier.height(12.dp))
        FileCard(vm, onPickFile)
        Spacer(Modifier.height(12.dp))
        Text("ملف الإكسل (.xlsx) يحتوي على سجل الأصول، ويُحفظ على جهازك ليكون البحث سريعاً.", color = C.Dim, fontSize = 12.sp)
    }
}

@Composable
fun AboutScreen(onMenu: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        DrawerTopBar("حول التطبيق", onMenu)
        Spacer(Modifier.height(12.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(C.Cyan, C.Violet)))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🏷️", fontSize = 44.sp)
            Spacer(Modifier.height(10.dp))
            Text("Asset Scanner", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("ابحث عن أي أصل بالتصوير أو بالرقم", fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
        }
        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            AboutRow("الإصدار", "1.0")
            AboutRow("المطوّر", "Abdelkader Ahmed")
            AboutRow("الحزمة", "com.pg.assetscanner")
        }
    }
}

@Composable
fun AboutRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(C.Card)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = C.Dim, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        Text(value, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
