package com.pg.assetscanner

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("asset_scanner_prefs", Context.MODE_PRIVATE)

    var hasFile by mutableStateOf(ExcelHelper.hasSavedFile(app))
    var fileName by mutableStateOf(ExcelHelper.getSavedFileName(app))
    var statusText by mutableStateOf("")          // مثال: تم تحميل 11207 أصل ✓
    var busy by mutableStateOf(false)
    var busyText by mutableStateOf("")

    var query by mutableStateOf("")
    var result by mutableStateOf<AssetModel?>(null)   // غير null = صفحة النتيجة
    var notFound by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    val recent = mutableStateListOf<String>()

    val availableColumns = mutableStateListOf<String>()
    val selectedColumns = mutableStateListOf<String>()

    init {
        prefs.getString("recent_queries", "")?.split("\n")?.filter { it.isNotBlank() }?.let { recent.addAll(it) }
        if (!prefs.getBoolean("dynamic_columns_v1", false)) {
            prefs.edit().remove("visible_asset_columns").putBoolean("dynamic_columns_v1", true).apply()
        }
        if (hasFile) preload()
    }

    /** تحميل الشيت في الذاكرة مسبقاً حتى يكون أول بحث فورياً. */
    private fun preload() {
        viewModelScope.launch {
            statusText = "جارٍ تحميل البيانات…"
            val t0 = System.currentTimeMillis()
            try {
                val n = withContext(Dispatchers.IO) { ExcelHelper.loadAllAssetsIntoCache(app).size }
                syncColumnsFromSheet()
                statusText = "تم تحميل $n أصل ✓ (${(System.currentTimeMillis() - t0) / 1000.0} ث)"
            } catch (e: Exception) {
                statusText = ""
                message = e.message
            }
        }
    }

    /** اختيار/تغيير ملف الأصول. */
    fun importFile(uri: Uri) {
        viewModelScope.launch {
            busy = true
            busyText = "جارٍ حفظ وقراءة الملف…"
            message = null
            notFound = null
            try {
                val t0 = System.currentTimeMillis()
                val n = withContext(Dispatchers.IO) {
                    val name = ExcelHelper.saveExcelFile(app, uri)
                    fileName = name
                    ExcelHelper.loadAllAssetsIntoCache(app).size
                }
                syncColumnsFromSheet()
                hasFile = true
                result = null
                statusText = "تم تحميل $n أصل ✓ (${(System.currentTimeMillis() - t0) / 1000.0} ث)"
            } catch (e: Exception) {
                message = e.message ?: "تعذّرت قراءة الملف"
            }
            busy = false
        }
    }

    fun performSearch(raw: String = query) {
        val q = raw.trim()
        message = null
        notFound = null
        if (q.isEmpty()) { message = "اكتب رقم الأصل أولاً"; return }
        if (!hasFile) { message = "يرجى الضغط على زر اختيار ملف الإكسل أولاً!"; return }
        query = q
        viewModelScope.launch {
            busy = true
            busyText = "جارٍ البحث…"
            try {
                val asset = withContext(Dispatchers.IO) { ExcelHelper.searchAsset(app, q) }
                if (asset != null) {
                    result = asset
                    addRecent(q)
                } else {
                    notFound = q
                }
            } catch (e: Exception) {
                message = "خطأ: " + (e.message ?: "")
            }
            busy = false
        }
    }

    /** البحث بالصورة: OCR ثم نفس البحث. */
    fun searchImage(uri: Uri) {
        viewModelScope.launch {
            busy = true
            busyText = "جارٍ قراءة الصورة…"
            message = null
            notFound = null
            var number: String? = null
            try {
                val text = OcrHelper.recognize(app, uri)
                number = OcrHelper.extractNumber(text)
                if (number == null) message = "لم يتم التعرف على رقم أصل في الصورة"
            } catch (e: Exception) {
                message = "خطأ في قراءة الصورة: " + (e.localizedMessage ?: "")
            }
            busy = false
            if (number != null) {
                query = number
                performSearch(number)
            }
        }
    }

    fun closeResult() { result = null }

    fun setColumnVisible(column: String, visible: Boolean) {
        if (visible && column !in selectedColumns) selectedColumns.add(column)
        if (!visible) selectedColumns.remove(column)
        prefs.edit().putStringSet("visible_asset_columns", selectedColumns.toSet()).apply()
    }

    fun selectAllColumns() {
        selectedColumns.clear()
        selectedColumns.addAll(availableColumns)
        prefs.edit().putStringSet("visible_asset_columns", selectedColumns.toSet()).apply()
    }

    private fun syncColumnsFromSheet() {
        val headers = ExcelHelper.getCurrentHeaders()
        availableColumns.clear()
        availableColumns.addAll(headers)
        val saved = prefs.getStringSet("visible_asset_columns", null)
        val keep = saved?.filter { it in headers }.orEmpty()
        selectedColumns.clear()
        selectedColumns.addAll(if (saved == null || (saved.isNotEmpty() && keep.isEmpty())) headers else keep)
        prefs.edit().putStringSet("visible_asset_columns", selectedColumns.toSet()).apply()
    }

    private fun addRecent(q: String) {
        recent.remove(q)
        recent.add(0, q)
        while (recent.size > 8) recent.removeAt(recent.size - 1)
        prefs.edit().putString("recent_queries", recent.joinToString("\n")).apply()
    }

    fun clearRecent() {
        recent.clear()
        prefs.edit().remove("recent_queries").apply()
    }
}
