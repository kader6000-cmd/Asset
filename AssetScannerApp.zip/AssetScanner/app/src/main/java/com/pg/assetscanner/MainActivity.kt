package com.pg.assetscanner

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private fun photoFile() = File(File(cacheDir, "photos"), "capture.jpg")
    private fun photoUri(): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pickExcel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.importFile(uri)
        }
        // صورة كاملة الدقة (أفضل للـ OCR من المعاينة المصغّرة)
        val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) vm.searchImage(photoUri())
        }
        val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) vm.searchImage(uri)
        }

        setContent {
            AssetTheme {
                AppRoot(
                    vm = vm,
                    onPickFile = { pickExcel.launch(arrayOf("*/*")) },
                    onCamera = {
                        val f = photoFile()
                        f.parentFile?.mkdirs()
                        if (f.exists()) f.delete()
                        takePhoto.launch(photoUri())
                    },
                    onGallery = { pickImage.launch("image/*") }
                )
            }
        }
    }
}
