package com.pg.assetscanner

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * نفس منطق التطبيق الأصلي:
 *  - نسخ الملف المختار إلى assets_database.xlsx داخل التطبيق
 *  - تحميل كل الأصول في الذاكرة (cache)
 *  - searchAsset: مطابقة Inventory Number أو (Main No. + Sub# اختياري) وإرجاع أول نتيجة
 */
object ExcelHelper {

    private const val PREFS_NAME = "asset_scanner_prefs"
    private const val SAVED_EXCEL_NAME = "excel_file_name"
    private const val DB_FILE = "assets_database.xlsx"
    private const val TEMP_FILE = "temp_upload.xlsx"

    private val REQUIRED_HEADERS = listOf(
        "Main No.", "Sub#", "Asset Description", "2nd Line Asset Desc", "Qty",
        "A.Class", "Cost Center", "Location", "Room", "Inventory Number", "Last Inv."
    )

    @Volatile private var currentHeaders: List<String> = emptyList()
    fun getCurrentHeaders(): List<String> = currentHeaders


    private var cachedAssets: List<AssetModel>? = null
    private var lastLoadedTimestamp: Long = 0L
    private var lastLoadedSize: Long = 0L

    fun hasSavedFile(context: Context): Boolean {
        val f = File(context.filesDir, DB_FILE)
        return f.exists() && f.length() > 0
    }

    fun getSavedFileName(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(SAVED_EXCEL_NAME, "") ?: ""

    fun getFileNameFromUri(context: Context, uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
        } catch (e: Exception) {
            // تجاهل
        }
        return name ?: (uri.lastPathSegment ?: "assets.xlsx")
    }

    /** يحفظ نسخة من الملف المختار. يرمي استثناء برسالة عربية عند الفشل. */
    @Synchronized
    fun saveExcelFile(context: Context, uri: Uri): String {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("تعذر فتح مسار الملف المختار")
        val temp = File(context.filesDir, TEMP_FILE)
        input.use { ins -> temp.outputStream().use { ins.copyTo(it) } }
        if (temp.length() == 0L) {
            temp.delete()
            throw IllegalStateException("الملف المختار فارغ (0 بايت). تأكد أن الملف محمل بالكامل على الهاتف")
        }
        val out = File(context.filesDir, DB_FILE)
        if (out.exists()) out.delete()
        temp.renameTo(out)

        val name = getFileNameFromUri(context, uri)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(SAVED_EXCEL_NAME, name).apply()
        cachedAssets = null
        return name
    }

    @Synchronized
    fun loadAllAssetsIntoCache(context: Context): List<AssetModel> {
        val file = File(context.filesDir, DB_FILE)
        if (!file.exists() || file.length() == 0L) {
            throw IllegalStateException("ملف الإكسل غير موجود، يرجى اختيار الملف من الزر العلوي")
        }
        val cached = cachedAssets
        if (cached != null && lastLoadedTimestamp == file.lastModified() && lastLoadedSize == file.length()) {
            return cached
        }
        val list: List<AssetModel>
        try {
            val headerSheet = XlsxReader.read(file, emptyList())
            val headers = headerSheet.headers.filter { it.isNotBlank() }
            if (headers.isEmpty()) throw IllegalStateException("لم يتم العثور على أسماء أعمدة في الصف الأول من الشيت")
            val missing = REQUIRED_HEADERS.filter { required -> headers.none { it.equals(required, true) } }
            if (missing.any { it == "Main No." || it == "Sub#" }) {
                throw IllegalStateException("الشيت يجب أن يحتوي على عمودي Main No. وSub# لإجراء البحث")
            }
            val sheet = XlsxReader.read(file, headers)
            currentHeaders = headers
            val index = headers.withIndex().associate { it.value.trim().lowercase() to it.index }
            fun value(row: Array<String>, name: String): String =
                index[name.lowercase()]?.let { row.getOrNull(it).orEmpty() } ?: ""
            list = sheet.rows.map { r ->
                val extras = headers.associateWith { h -> value(r, h) }
                AssetModel(
                    mainNo = cleanNumericString(value(r, "Main No.")),
                    subNo = cleanNumericString(value(r, "Sub#")),
                    description = value(r, "Asset Description"),
                    secondLineDesc = value(r, "2nd Line Asset Desc"),
                    qty = cleanNumericString(value(r, "Qty")),
                    assetClass = value(r, "A.Class"),
                    costCenter = value(r, "Cost Center"),
                    location = value(r, "Location"),
                    room = value(r, "Room"),
                    inventoryNumber = value(r, "Inventory Number"),
                    lastInv = formatExcelDateIfNeeded(value(r, "Last Inv.")),
                    extraFields = extras
                )
            }
        } catch (e: Exception) {
            throw IllegalStateException("خطأ أثناء قراءة الملف: " + (e.localizedMessage ?: ""))
        }
        if (list.isEmpty()) throw IllegalStateException("لم يتم العثور على بيانات داخل ملف الإكسل")
        cachedAssets = list
        lastLoadedTimestamp = file.lastModified()
        lastLoadedSize = file.length()
        return list
    }

    /**
     * طريقة جلب النتيجة كما في التطبيق الأصلي تماماً:
     * Inventory Number (بدون حساسية لحالة الأحرف) أو Main No. (+ Sub# إن وُجد) — أول نتيجة في الشيت.
     */
    fun searchAsset(context: Context, rawQuery: String): AssetModel? {
        val list = loadAllAssetsIntoCache(context)
        val cleanQuery = rawQuery.trim().replace(" ", "")
        val parts = cleanQuery.split("-")
        val targetMain = parts[0]
        val targetSub: String? = if (parts.size > 1) parts[1] else null
        return list.firstOrNull {
            it.inventoryNumber.equals(cleanQuery, ignoreCase = true) ||
                (it.mainNo == targetMain && (targetSub == null || it.subNo == targetSub))
        }
    }

    private fun cleanNumericString(raw: String): String {
        if (raw.isEmpty()) return ""
        if (raw.contains("E") || raw.endsWith(".0")) {
            val d = raw.toDoubleOrNull()
            if (d != null) {
                return if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else raw
            }
        }
        return raw
    }

    /** تاريخ Excel الرقمي (serial) → dd/MM/yyyy ، وغير ذلك يبقى كما هو. */
    private fun formatExcelDateIfNeeded(raw: String): String {
        if (raw.isEmpty() || raw.contains("-") || raw.contains("/")) return raw
        val d = raw.toDoubleOrNull() ?: return raw
        if (d < 10000 || d > 100000) return raw
        val utc = TimeZone.getTimeZone("UTC")
        val cal = Calendar.getInstance(utc)
        cal.set(1899, 11, 30, 0, 0, 0)
        cal.add(Calendar.DAY_OF_YEAR, d.toInt())
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        sdf.timeZone = utc
        return sdf.format(cal.time)
    }
}
