package com.pg.assetscanner

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.math.BigDecimal
import java.util.zip.ZipFile

/** نتيجة قراءة الجدول: found[i] = هل وُجد العمود المطلوب رقم i، و rows = الصفوف بالأعمدة المطلوبة فقط. */
class ParsedSheet(val found: BooleanArray, val rows: List<Array<String>>, val headers: List<String>)

/**
 * قارئ xlsx خفيف (بدون Apache POI) يعتمد على ZipFile + XmlPullParser،
 * يقرأ أول ورقة ويستخرج الأعمدة المطلوبة حسب اسم العمود في الصف الأول.
 */
object XlsxReader {

    fun read(file: File, wanted: List<String>): ParsedSheet {
        return ZipFile(file).use { zip ->
            val shared = ArrayList<String>()
            val sst = zip.getEntry("xl/sharedStrings.xml")
            if (sst != null) {
                zip.getInputStream(sst).buffered().use { readSharedStrings(it, shared) }
            }
            val sheetEntry = zip.getEntry("xl/worksheets/sheet1.xml")
                ?: zip.entries().asSequence()
                    .filter { it.name.startsWith("xl/worksheets/") && it.name.endsWith(".xml") }
                    .minByOrNull { it.name }
                ?: throw IllegalArgumentException("الملف ليس ملف Excel (.xlsx) صالحاً")
            zip.getInputStream(sheetEntry).buffered().use { readSheet(it, shared, wanted) }
        }
    }

    private fun readSharedStrings(input: InputStream, out: ArrayList<String>) {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        val sb = StringBuilder()
        var inSi = false
        var phonetic = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "si" -> { inSi = true; sb.setLength(0); phonetic = 0 }
                    "rPh" -> { if (inSi) phonetic++ }
                    "t" -> { if (inSi && phonetic == 0) sb.append(p.nextText()) }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "rPh" -> { if (phonetic > 0) phonetic-- }
                    "si" -> { out.add(sb.toString()); inSi = false }
                }
            }
            ev = p.next()
        }
    }

    private fun readSheet(input: InputStream, shared: List<String>, wanted: List<String>): ParsedSheet {
        val p = Xml.newPullParser()
        p.setInput(input, null)

        val wantedNorm = wanted.map { it.trim().lowercase() }
        val found = BooleanArray(wanted.size)
        val rows = ArrayList<Array<String>>()
        var headers: List<String> = emptyList()
        var colFor: IntArray? = null

        val cells = HashMap<Int, String>()
        var col = 0
        var lastCol = -1
        var type: String? = null
        var raw: String? = null
        val inline = StringBuilder()
        var inInline = false

        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "row" -> { cells.clear(); lastCol = -1 }
                    "c" -> {
                        val ref = p.getAttributeValue(null, "r")
                        col = if (ref != null) colIndex(ref) else lastCol + 1
                        lastCol = col
                        type = p.getAttributeValue(null, "t")
                        raw = null
                        inline.setLength(0)
                    }
                    "is" -> inInline = true
                    "v" -> raw = p.nextText()
                    "t" -> { if (inInline) inline.append(p.nextText()) }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "is" -> inInline = false
                    "c" -> {
                        val r = raw
                        val v: String = when (type) {
                            "s" -> r?.trim()?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                            "inlineStr" -> inline.toString()
                            "b" -> if (r == "1") "TRUE" else "FALSE"
                            else -> numeric(r)
                        }
                        if (v.isNotEmpty()) cells[col] = v
                    }
                    "row" -> {
                        val cf = colFor
                        if (cf == null) {
                            if (cells.isNotEmpty()) {
                                val headerMap = HashMap<String, Int>()
                                for ((c, v) in cells) {
                                    val k = v.trim().lowercase()
                                    val cur = headerMap[k]
                                    if (cur == null || c < cur) headerMap[k] = c
                                }
                                val orderedHeaders = cells.entries.sortedBy { it.key }
                                headers = orderedHeaders.map { it.value.trim() }
                                val arr = if (wanted.isEmpty()) {
                                    IntArray(orderedHeaders.size) { i -> orderedHeaders[i].key }
                                } else {
                                    IntArray(wanted.size) { i -> headerMap[wantedNorm[i]] ?: -1 }
                                }
                                for (i in wanted.indices) found[i] = arr.getOrNull(i)?.let { it >= 0 } ?: false
                                colFor = arr
                            }
                        } else {
                            val row = Array(wanted.size) { i ->
                                val c = cf[i]
                                if (c >= 0) (cells[c] ?: "").trim() else ""
                            }
                            if (row.any { it.isNotEmpty() }) rows.add(row)
                        }
                    }
                }
            }
            ev = p.next()
        }
        return ParsedSheet(found, rows, headers)
    }

    private fun numeric(raw: String?): String {
        if (raw == null) return ""
        val s = raw.trim()
        if (s.isEmpty()) return ""
        return if (s.contains('E') || s.contains('e') || s.contains('.')) {
            try {
                BigDecimal(s).stripTrailingZeros().toPlainString()
            } catch (e: Exception) {
                s
            }
        } else s
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break
        }
        return n - 1
    }
}
