plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pg.assetscanner"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pg.assetscanner"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        create("release") {
            val ksPath = System.getenv("KEYSTORE_FILE") ?: ""
            if (ksPath.isNotBlank() && file(ksPath).exists()) {
                storeFile = file(ksPath)
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
                // اسم المفتاح ثابت في المخزن ("nova") — مكتوب هنا مباشرة بدل قراءته
                // من Secret، لأن قيمة الـ Secret كانت تصل بشكل غير مطابق
                keyAlias = "nova"
                // كلمة سر المفتاح هي نفسها كلمة سر المخزن، فنستخدم نفس المتغير
                keyPassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // يوقّع بتوقيعك الخاص عندما تكون متغيرات الـ keystore موجودة (بناء GitHub)،
            // وإلا يرجع لتوقيع debug مثل قبل
            val releaseSign = signingConfigs.getByName("release")
            signingConfig = if (releaseSign.storeFile != null) {
                releaseSign
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // قراءة النص من الصورة (OCR) تعمل بدون إنترنت
    implementation("com.google.mlkit:text-recognition:16.0.0")
}
