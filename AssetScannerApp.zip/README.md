# Asset Scanner Android App v5 (Ultra-Fast XML Streaming Parser)
