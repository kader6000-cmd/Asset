package com.pg.assetscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.pg.assetscanner.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val pickExcelLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }

            binding.progressBar.visibility = View.VISIBLE
            lifecycleScope.launch(Dispatchers.IO) {
                val (saved, message) = ExcelHelper.saveExcelFile(this@MainActivity, it)
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    updateFileStatus()
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val requestCameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            takePictureLauncher.launch(null)
        } else {
            Toast.makeText(this, "يجب منح صلاحية الكاميرا للتصوير", Toast.LENGTH_SHORT).show()
        }
    }

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        bitmap?.let {
            val image = InputImage.fromBitmap(it, 0)
            processImageForAssetNumber(image)
        }
    }

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val image = InputImage.fromFilePath(this, it)
                processImageForAssetNumber(image)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر فتح الصورة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        System.setProperty("org.apache.poi.javax.xml.stream.XMLInputFactory", "com.fasterxml.aalto.stax.InputFactoryImpl")
        System.setProperty("org.apache.poi.javax.xml.stream.XMLOutputFactory", "com.fasterxml.aalto.stax.OutputFactoryImpl")
        System.setProperty("org.apache.poi.javax.xml.stream.XMLEventFactory", "com.fasterxml.aalto.stax.EventFactoryImpl")

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateFileStatus()

        // تحميل مسبق لملف الإكسل في الخلفية فور فتح التطبيق لتسريع البحث
        if (ExcelHelper.hasSavedFile(this)) {
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    ExcelHelper.loadAllAssetsIntoCache(this@MainActivity)
                } catch (_: Throwable) { }
            }
        }

        binding.btnSelectExcel.setOnClickListener {
            pickExcelLauncher.launch(arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel",
                "*/*"
            ))
        }

        binding.btnSearch.setOnClickListener {
            val query = binding.etSearchQuery.text.toString()
            if (query.isNotBlank()) {
                performSearch(query)
            } else {
                Toast.makeText(this, "اكتب رقم الأصل أولاً", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnCamera.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                takePictureLauncher.launch(null)
            } else {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnGallery.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
    }

    private fun updateFileStatus() {
        val savedName = ExcelHelper.getSavedFileName(this)
        if (savedName != null) {
            binding.tvFileStatus.text = "الملف النشط: $savedName ✓"
        } else {
            binding.tvFileStatus.text = "يرجى اختيار ملف الإكسل (.xlsx) للبدء"
        }
    }

    private fun processImageForAssetNumber(image: InputImage) {
        binding.progressBar.visibility = View.VISIBLE
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                binding.progressBar.visibility = View.GONE
                val rawText = visionText.text
                val regex = Regex("""\b\d{9,15}(-\d+)?\b""")
                val match = regex.find(rawText)

                if (match != null) {
                    val extractedNumber = match.value
                    binding.etSearchQuery.setText(extractedNumber)
                    performSearch(extractedNumber)
                } else {
                    Toast.makeText(this, "لم يتم التعرف على رقم أصل في الصورة", Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener { e ->
                binding.progressBar.visibility = View.GONE
                Toast.makeText(this, "خطأ في قراءة الصورة: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
    }

    private fun performSearch(query: String) {
        if (!ExcelHelper.hasSavedFile(this)) {
            Toast.makeText(this, "يرجى الضغط على زر اختيار ملف الإكسل أولاً!", Toast.LENGTH_LONG).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val asset = ExcelHelper.searchAsset(this@MainActivity, query)
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    if (asset != null) {
                        displayAssetCard(asset)
                    } else {
                        binding.cardResult.visibility = View.GONE
                        Toast.makeText(this@MainActivity, "الأصل ($query) غير موجود في الشيت", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Throwable) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.cardResult.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun displayAssetCard(asset: AssetModel) {
        binding.cardResult.visibility = View.VISIBLE
        binding.tvBadgeInv.text = asset.inventoryNumber
        binding.layoutDataRows.removeAllViews()

        val rows = listOf(
            "Main No." to asset.mainNo,
            "Sub#" to asset.subNo,
            "Asset Description" to asset.description,
            "2nd Line Asset Desc" to asset.secondLineDesc,
            "Qty" to asset.qty,
            "A.Class" to asset.assetClass,
            "Cost Center" to asset.costCenter,
            "Location" to asset.location,
            "Room" to asset.room,
            "Inventory Number" to asset.inventoryNumber,
            "Last Inv." to asset.lastInv
        )

        rows.forEachIndexed { index, (label, value) ->
            // صف من عمودين من الشمال لليمين (LTR): العمود الشمال لاسم الحقل، والعمود اليمين للنتيجة
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(32, 28, 32, 28)
                setBackgroundColor(if (index % 2 == 0) Color.parseColor("#F8FAFC") else Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
            }

            // العمود الشمال: اسم العمود في الشيت
            val tvLabel = TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#1E3A8A"))
                textSize = 15.5f
                setTypeface(null, Typeface.BOLD)
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.44f)
            }

            // فاصل عمودي رفيع بين العمودين
            val divider = View(this).apply {
                setBackgroundColor(Color.parseColor("#CBD5E1"))
                layoutParams = LinearLayout.LayoutParams(2, LinearLayout.LayoutParams.MATCH_PARENT).apply {
                    setMargins(16, 0, 16, 0)
                }
            }

            // العمود اليمين: النتيجة المستخرجة بخط واضح وكبير
            val tvValue = TextView(this).apply {
                text = value
                setTextColor(Color.parseColor("#0F172A"))
                textSize = 16.5f
                setTypeface(null, Typeface.BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.56f)
            }

            rowLayout.addView(tvLabel)
            rowLayout.addView(divider)
            rowLayout.addView(tvValue)
            binding.layoutDataRows.addView(rowLayout)

            // خط أفقي فاصل بين الصفوف
            if (index < rows.size - 1) {
                val hLine = View(this).apply {
                    setBackgroundColor(Color.parseColor("#E2E8F0"))
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2)
                }
                binding.layoutDataRows.addView(hLine)
            }
        }
    }
}
