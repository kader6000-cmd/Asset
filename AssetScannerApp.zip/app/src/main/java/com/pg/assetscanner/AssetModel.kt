package com.pg.assetscanner

data class AssetModel(
    val mainNo: String,
    val subNo: String,
    val description: String,
    val assetClass: String,
    val costCenter: String,
    val location: String,
    val room: String,
    val inventoryNumber: String,
    val lastInv: String
)
