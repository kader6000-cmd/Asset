package com.pg.assetscanner

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipFile

object ExcelHelper {
    private const val SAVED_EXCEL_NAME = "assets_database.xlsx"
    private const val PREFS_NAME = "asset_scanner_prefs"
    private const val KEY_FILE_NAME = "excel_file_name"

    private var cachedAssets: List<AssetModel>? = null
    private var lastLoadedTimestamp: Long = 0L

    fun saveExcelFile(context: Context, uri: Uri): Pair<Boolean, String> {
        return try {
            val fileName = getFileNameFromUri(context, uri) ?: "assets_database.xlsx"
            val tempFile = File(context.filesDir, "temp_upload.xlsx")
            val outFile = File(context.filesDir, SAVED_EXCEL_NAME)

            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return Pair(false, "تعذر فتح مسار الملف المختار")

            var totalBytes = 0L
            FileOutputStream(tempFile).use { output ->
                totalBytes = inputStream.copyTo(output)
            }
            inputStream.close()

            if (totalBytes <= 0L || !tempFile.exists() || tempFile.length() <= 0L) {
                tempFile.delete()
                return Pair(false, "الملف المختار فارغ (0 بايت). تأكد أن الملف محمل بالكامل على الهاتف")
            }

            if (outFile.exists()) outFile.delete()
            tempFile.renameTo(outFile)

            cachedAssets = null
            lastLoadedTimestamp = 0L
            val loadedList = loadAllAssetsIntoCache(context)

            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_FILE_NAME, fileName)
                .apply()

            Pair(true, "تم تحميل ${loadedList.size} أصل في أقل من ثانية ✓")
        } catch (e: Exception) {
            e.printStackTrace()
            Pair(false, "خطأ أثناء قراءة الملف: ${e.localizedMessage}")
        }
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String? {
        var name: String? = null
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = it.getString(idx)
            }
        }
        return name
    }

    fun getSavedFileName(context: Context): String? {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        if (!file.exists() || file.length() == 0L) return null
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FILE_NAME, SAVED_EXCEL_NAME)
    }

    fun hasSavedFile(context: Context): Boolean {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        return file.exists() && file.length() > 0L
    }

    @Synchronized
    fun loadAllAssetsIntoCache(context: Context): List<AssetModel> {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        if (!file.exists() || file.length() == 0L) {
            throw IllegalStateException("ملف الإكسل غير موجود، يرجى اختيار الملف من الزر العلوي")
        }

        val currentModified = file.lastModified()
        if (cachedAssets != null && lastLoadedTimestamp == currentModified) {
            return cachedAssets!!
        }

        val list = ArrayList<AssetModel>(3000)

        ZipFile(file).use { zip ->
            // 1. قراءة جدول النصوص المشتركة (sharedStrings.xml)
            val sharedStrings = ArrayList<String>(4000)
            val ssEntry = zip.getEntry("xl/sharedStrings.xml")
            if (ssEntry != null) {
                zip.getInputStream(ssEntry).use { ssStream ->
                    parseSharedStrings(ssStream, sharedStrings)
                }
            }

            // 2. قراءة ورقة البيانات الأولى (sheet1.xml) بتقنية Streaming الخفيفة
            val sheetEntry = zip.getEntry("xl/worksheets/sheet1.xml")
                ?: throw IllegalStateException("لم يتم العثور على بيانات داخل ملف الإكسل")

            zip.getInputStream(sheetEntry).use { sheetStream ->
                parseSheetStream(sheetStream, sharedStrings, list)
            }
        }

        cachedAssets = list
        lastLoadedTimestamp = currentModified
        return list
    }

    private fun parseSharedStrings(stream: InputStream, outList: ArrayList<String>) {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(stream, "UTF-8")

        var eventType = parser.eventType
        val sb = StringBuilder()
        var inSi = false
        var inT = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "si" -> {
                            inSi = true
                            sb.setLength(0)
                        }
                        "t" -> if (inSi) inT = true
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inSi && inT) {
                        sb.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "t" -> inT = false
                        "si" -> {
                            inSi = false
                            outList.add(sb.toString())
                        }
                    }
                }
            }
            eventType = parser.next()
        }
    }

    private fun parseSheetStream(
        stream: InputStream,
        sharedStrings: List<String>,
        outAssets: ArrayList<AssetModel>
    ) {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(stream, "UTF-8")

        var eventType = parser.eventType
        var currentRowNum = 0
        val currentRowCells = HashMap<Int, String>(40)
        var currentColIdx = -1
        var currentCellType: String? = null
        var inValueTag = false
        val valueBuilder = StringBuilder()

        var idxMain = -1
        var idxSub = -1
        var idxDesc = -1
        var idx2ndDesc = -1
        var idxQty = -1
        var idxClass = -1
        var idxCost = -1
        var idxLoc = -1
        var idxRoom = -1
        var idxInv = -1
        var idxLastInv = -1

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> {
                            currentRowCells.clear()
                            val rAttr = parser.getAttributeValue(null, "r")
                            currentRowNum = rAttr?.toIntOrNull() ?: (currentRowNum + 1)
                        }
                        "c" -> {
                            val ref = parser.getAttributeValue(null, "r") ?: ""
                            currentColIdx = columnRefToIndex(ref)
                            currentCellType = parser.getAttributeValue(null, "t")
                            valueBuilder.setLength(0)
                        }
                        "v", "t" -> {
                            inValueTag = true
                            valueBuilder.setLength(0)
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inValueTag) {
                        valueBuilder.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v", "t" -> inValueTag = false
                        "c" -> {
                            if (currentColIdx >= 0) {
                                val rawVal = valueBuilder.toString().trim()
                                val resolvedVal = when (currentCellType) {
                                    "s" -> {
                                        val idx = rawVal.toIntOrNull()
                                        if (idx != null && idx in sharedStrings.indices) sharedStrings[idx] else rawVal
                                    }
                                    else -> cleanNumericString(rawVal)
                                }
                                currentRowCells[currentColIdx] = resolvedVal.trim()
                            }
                        }
                        "row" -> {
                            if (currentRowNum == 1) {
                                for ((colIdx, headerName) in currentRowCells) {
                                    when (headerName.trim()) {
                                        "Main No." -> idxMain = colIdx
                                        "Sub#" -> idxSub = colIdx
                                        "Asset Description" -> idxDesc = colIdx
                                        "2nd Line Asset Desc" -> idx2ndDesc = colIdx
                                        "Qty" -> idxQty = colIdx
                                        "A.Class" -> idxClass = colIdx
                                        "Cost Center" -> idxCost = colIdx
                                        "Location" -> idxLoc = colIdx
                                        "Room" -> idxRoom = colIdx
                                        "Inventory Number" -> idxInv = colIdx
                                        "Last Inv." -> idxLastInv = colIdx
                                    }
                                }
                            } else if (idxMain >= 0) {
                                val mainVal = currentRowCells[idxMain] ?: ""
                                if (mainVal.isNotEmpty()) {
                                    val subVal = if (idxSub >= 0) currentRowCells[idxSub] ?: "" else ""
                                    val invVal = if (idxInv >= 0) currentRowCells[idxInv] ?: "" else ""
                                    val rawLastInv = if (idxLastInv >= 0) currentRowCells[idxLastInv] ?: "" else ""

                                    outAssets.add(
                                        AssetModel(
                                            mainNo = mainVal,
                                            subNo = subVal.ifEmpty { "-" },
                                            description = (if (idxDesc >= 0) currentRowCells[idxDesc] else null)?.ifEmpty { "-" } ?: "-",
                                            secondLineDesc = (if (idx2ndDesc >= 0) currentRowCells[idx2ndDesc] else null)?.ifEmpty { "-" } ?: "-",
                                            qty = (if (idxQty >= 0) currentRowCells[idxQty] else null)?.ifEmpty { "-" } ?: "-",
                                            assetClass = (if (idxClass >= 0) currentRowCells[idxClass] else null)?.ifEmpty { "-" } ?: "-",
                                            costCenter = (if (idxCost >= 0) currentRowCells[idxCost] else null)?.ifEmpty { "-" } ?: "-",
                                            location = (if (idxLoc >= 0) currentRowCells[idxLoc] else null)?.ifEmpty { "-" } ?: "-",
                                            room = (if (idxRoom >= 0) currentRowCells[idxRoom] else null)?.ifEmpty { "-" } ?: "-",
                                            inventoryNumber = invVal.ifEmpty { if (subVal.isNotEmpty()) "$mainVal-$subVal" else mainVal },
                                            lastInv = formatExcelDateIfNeeded(rawLastInv)
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
            eventType = parser.next()
        }
    }

    private fun columnRefToIndex(cellRef: String): Int {
        var col = 0
        for (ch in cellRef) {
            if (ch in 'A'..'Z') {
                col = col * 26 + (ch - 'A' + 1)
            } else if (ch in 'a'..'z') {
                col = col * 26 + (ch - 'a' + 1)
            } else {
                break
            }
        }
        return col - 1
    }

    private fun cleanNumericString(raw: String): String {
        if (raw.isEmpty()) return ""
        // تحويل الأرقام العلمية أو العشرية الصفرية مثل 200000131051.0 أو 2.00000131051E11 إلى نص رقمي صحيح
        if (raw.contains("E", ignoreCase = true) || raw.endsWith(".0")) {
            val d = raw.toDoubleOrNull()
            if (d != null && d % 1.0 == 0.0) {
                return d.toLong().toString()
            }
        }
        return raw
    }

    private fun formatExcelDateIfNeeded(raw: String): String {
        if (raw.isEmpty()) return "-"
        val serial = raw.toDoubleOrNull() ?: return raw
        if (serial in 20000.0..80000.0) {
            return try {
                val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                cal.set(1899, Calendar.DECEMBER, 30, 0, 0, 0)
                cal.add(Calendar.DAY_OF_YEAR, serial.toInt())
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                sdf.format(cal.time)
            } catch (_: Exception) {
                raw
            }
        }
        return raw
    }

    fun searchAsset(context: Context, rawQuery: String): AssetModel? {
        val assets = loadAllAssetsIntoCache(context)
        val cleanQuery = rawQuery.trim().replace(" ", "")
        val parts = cleanQuery.split("-")
        val targetMain = parts[0]
        val targetSub = if (parts.size > 1) parts[1] else null

        return assets.firstOrNull { asset ->
            asset.inventoryNumber.equals(cleanQuery, ignoreCase = true) ||
                    (asset.mainNo == targetMain && (targetSub == null || asset.subNo == targetSub))
        }
    }
}
