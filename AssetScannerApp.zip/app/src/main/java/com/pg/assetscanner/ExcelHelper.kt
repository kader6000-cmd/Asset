package com.pg.assetscanner

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object ExcelHelper {
    private const val SAVED_EXCEL_NAME = "assets_database.xlsx"
    private const val PREFS_NAME = "asset_scanner_prefs"
    private const val KEY_FILE_NAME = "excel_file_name"

    // ذاكرة تخزين مؤقت في الرام (RAM Cache) لتسريع البحث الفوري لأجزاء من الثانية
    private var cachedAssets: List<AssetModel>? = null
    private var lastLoadedTimestamp: Long = 0L

    fun saveExcelFile(context: Context, uri: Uri): Pair<Boolean, String> {
        return try {
            val fileName = getFileNameFromUri(context, uri) ?: "assets_database.xlsx"
            val tempFile = File(context.filesDir, "temp_upload.xlsx")
            val outFile = File(context.filesDir, SAVED_EXCEL_NAME)

            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return Pair(false, "تعذر فتح مسار الملف المختار")

            var totalBytes = 0L
            FileOutputStream(tempFile).use { output ->
                totalBytes = inputStream.copyTo(output)
            }
            inputStream.close()

            if (totalBytes <= 0L || !tempFile.exists() || tempFile.length() <= 0L) {
                tempFile.delete()
                return Pair(false, "الملف المختار فارغ (0 بايت). تأكد أن الملف محمل بالكامل على الهاتف")
            }

            if (outFile.exists()) outFile.delete()
            tempFile.renameTo(outFile)

            // تفريغ الكاش القديم وإعادة تحميل البيانات الجديدة في الذاكرة فوراً
            cachedAssets = null
            lastLoadedTimestamp = 0L
            loadAllAssetsIntoCache(context)

            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_FILE_NAME, fileName)
                .apply()

            val count = cachedAssets?.size ?: 0
            Pair(true, "تم حفظ وتجهيز $count أصل بنجاح (${outFile.length() / 1024} KB)")
        } catch (e: Exception) {
            e.printStackTrace()
            Pair(false, "خطأ أثناء قراءة الملف: ${e.localizedMessage}")
        }
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String? {
        var name: String? = null
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = it.getString(idx)
            }
        }
        return name
    }

    fun getSavedFileName(context: Context): String? {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        if (!file.exists() || file.length() == 0L) return null
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FILE_NAME, SAVED_EXCEL_NAME)
    }

    fun hasSavedFile(context: Context): Boolean {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        return file.exists() && file.length() > 0L
    }

    @Synchronized
    fun loadAllAssetsIntoCache(context: Context): List<AssetModel> {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        if (!file.exists() || file.length() == 0L) {
            throw IllegalStateException("ملف الإكسل غير موجود أو فارغ، يرجى إعادة اختيار الملف من الزر العلوي")
        }

        val currentModified = file.lastModified()
        if (cachedAssets != null && lastLoadedTimestamp == currentModified) {
            return cachedAssets!!
        }

        val list = ArrayList<AssetModel>(3000)
        FileInputStream(file).use { fis ->
            val workbook = XSSFWorkbook(fis)
            val sheet = workbook.getSheetAt(0)
            val formatter = DataFormatter()

            val headerRow = sheet.getRow(0) ?: run {
                workbook.close()
                return emptyList()
            }
            val colMap = mutableMapOf<String, Int>()
            for (cell in headerRow) {
                colMap[formatter.formatCellValue(cell).trim()] = cell.columnIndex
            }

            val idxMain = colMap["Main No."] ?: run {
                workbook.close()
                throw IllegalArgumentException("لم يتم العثور على عمود 'Main No.' في الشيت")
            }
            val idxSub = colMap["Sub#"] ?: -1
            val idxDesc = colMap["Asset Description"] ?: -1
            val idx2ndDesc = colMap["2nd Line Asset Desc"] ?: -1
            val idxQty = colMap["Qty"] ?: -1
            val idxClass = colMap["A.Class"] ?: -1
            val idxCost = colMap["Cost Center"] ?: -1
            val idxLoc = colMap["Location"] ?: -1
            val idxRoom = colMap["Room"] ?: -1
            val idxInv = colMap["Inventory Number"] ?: -1
            val idxLastInv = colMap["Last Inv."] ?: -1

            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i) ?: continue
                val mainVal = formatter.formatCellValue(row.getCell(idxMain)).trim()
                if (mainVal.isEmpty()) continue

                val subVal = if (idxSub != -1) formatter.formatCellValue(row.getCell(idxSub)).trim() else ""
                val invVal = if (idxInv != -1) formatter.formatCellValue(row.getCell(idxInv)).trim() else ""

                list.add(
                    AssetModel(
                        mainNo = mainVal,
                        subNo = subVal.ifEmpty { "-" },
                        description = if (idxDesc != -1) formatter.formatCellValue(row.getCell(idxDesc)).trim().ifEmpty { "-" } else "-",
                        secondLineDesc = if (idx2ndDesc != -1) formatter.formatCellValue(row.getCell(idx2ndDesc)).trim().ifEmpty { "-" } else "-",
                        qty = if (idxQty != -1) formatter.formatCellValue(row.getCell(idxQty)).trim().ifEmpty { "-" } else "-",
                        assetClass = if (idxClass != -1) formatter.formatCellValue(row.getCell(idxClass)).trim().ifEmpty { "-" } else "-",
                        costCenter = if (idxCost != -1) formatter.formatCellValue(row.getCell(idxCost)).trim().ifEmpty { "-" } else "-",
                        location = if (idxLoc != -1) formatter.formatCellValue(row.getCell(idxLoc)).trim().ifEmpty { "-" } else "-",
                        room = if (idxRoom != -1) formatter.formatCellValue(row.getCell(idxRoom)).trim().ifEmpty { "-" } else "-",
                        inventoryNumber = invVal.ifEmpty { if (subVal.isNotEmpty()) "$mainVal-$subVal" else mainVal },
                        lastInv = if (idxLastInv != -1) formatter.formatCellValue(row.getCell(idxLastInv)).trim().ifEmpty { "-" } else "-"
                    )
                )
            }
            workbook.close()
        }

        cachedAssets = list
        lastLoadedTimestamp = currentModified
        return list
    }

    fun searchAsset(context: Context, rawQuery: String): AssetModel? {
        val assets = loadAllAssetsIntoCache(context)
        val cleanQuery = rawQuery.trim().replace(" ", "")
        val parts = cleanQuery.split("-")
        val targetMain = parts[0]
        val targetSub = if (parts.size > 1) parts[1] else null

        return assets.firstOrNull { asset ->
            asset.inventoryNumber.equals(cleanQuery, ignoreCase = true) ||
                    (asset.mainNo == targetMain && (targetSub == null || asset.subNo == targetSub))
        }
    }
}
