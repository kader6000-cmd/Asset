package com.pg.assetscanner

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object ExcelHelper {
    private const val SAVED_EXCEL_NAME = "assets_database.xlsx"
    private const val PREFS_NAME = "asset_scanner_prefs"
    private const val KEY_FILE_NAME = "excel_file_name"

    fun saveExcelFile(context: Context, uri: Uri): Pair<Boolean, String> {
        return try {
            val fileName = getFileNameFromUri(context, uri) ?: "assets_database.xlsx"
            val tempFile = File(context.filesDir, "temp_upload.xlsx")
            val outFile = File(context.filesDir, SAVED_EXCEL_NAME)

            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return Pair(false, "تعذر فتح مسار الملف المختار")

            var totalBytes = 0L
            FileOutputStream(tempFile).use { output ->
                totalBytes = inputStream.copyTo(output)
            }
            inputStream.close()

            if (totalBytes <= 0L || !tempFile.exists() || tempFile.length() <= 0L) {
                tempFile.delete()
                return Pair(false, "الملف المختار فارغ (0 بايت). تأكد أن الملف محمل بالكامل على الهاتف وليس اختصاراً سحابياً")
            }

            if (outFile.exists()) outFile.delete()
            tempFile.renameTo(outFile)

            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_FILE_NAME, fileName)
                .apply()

            Pair(true, "تم حفظ الملف بنجاح (${outFile.length() / 1024} KB)")
        } catch (e: Exception) {
            e.printStackTrace()
            Pair(false, "خطأ أثناء نسخ الملف: ${e.localizedMessage}")
        }
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String? {
        var name: String? = null
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = it.getString(idx)
            }
        }
        return name
    }

    fun getSavedFileName(context: Context): String? {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        if (!file.exists() || file.length() == 0L) return null
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FILE_NAME, SAVED_EXCEL_NAME)
    }

    fun hasSavedFile(context: Context): Boolean {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        return file.exists() && file.length() > 0L
    }

    fun searchAsset(context: Context, rawQuery: String): AssetModel? {
        val file = File(context.filesDir, SAVED_EXCEL_NAME)
        if (!file.exists() || file.length() == 0L) {
            throw IllegalStateException("ملف الإكسل غير موجود أو فارغ، يرجى إعادة اختيار الملف من الزر العلوي")
        }

        val cleanQuery = rawQuery.trim().replace(" ", "")
        val parts = cleanQuery.split("-")
        val targetMain = parts[0]
        val targetSub = if (parts.size > 1) parts[1] else null

        FileInputStream(file).use { fis ->
            val workbook = XSSFWorkbook(fis)
            val sheet = workbook.getSheetAt(0)
            val formatter = DataFormatter()

            val headerRow = sheet.getRow(0) ?: run {
                workbook.close()
                return null
            }
            val colMap = mutableMapOf<String, Int>()
            for (cell in headerRow) {
                colMap[formatter.formatCellValue(cell).trim()] = cell.columnIndex
            }

            val idxMain = colMap["Main No."] ?: run {
                workbook.close()
                throw IllegalArgumentException("لم يتم العثور على عمود 'Main No.' في الشيت")
            }
            val idxSub = colMap["Sub#"] ?: -1
            val idxDesc = colMap["Asset Description"] ?: -1
            val idxClass = colMap["A.Class"] ?: -1
            val idxCost = colMap["Cost Center"] ?: -1
            val idxLoc = colMap["Location"] ?: -1
            val idxRoom = colMap["Room"] ?: -1
            val idxInv = colMap["Inventory Number"] ?: -1
            val idxLastInv = colMap["Last Inv."] ?: -1

            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i) ?: continue
                val mainVal = formatter.formatCellValue(row.getCell(idxMain)).trim()
                val subVal = if (idxSub != -1) formatter.formatCellValue(row.getCell(idxSub)).trim() else ""
                val invVal = if (idxInv != -1) formatter.formatCellValue(row.getCell(idxInv)).trim() else ""

                val isMatch = invVal.equals(cleanQuery, ignoreCase = true) ||
                        (mainVal == targetMain && (targetSub == null || subVal == targetSub))

                if (isMatch) {
                    val result = AssetModel(
                        mainNo = mainVal.ifEmpty { "-" },
                        subNo = subVal.ifEmpty { "-" },
                        description = if (idxDesc != -1) formatter.formatCellValue(row.getCell(idxDesc)).ifEmpty { "-" } else "-",
                        assetClass = if (idxClass != -1) formatter.formatCellValue(row.getCell(idxClass)).ifEmpty { "-" } else "-",
                        costCenter = if (idxCost != -1) formatter.formatCellValue(row.getCell(idxCost)).ifEmpty { "-" } else "-",
                        location = if (idxLoc != -1) formatter.formatCellValue(row.getCell(idxLoc)).ifEmpty { "-" } else "-",
                        room = if (idxRoom != -1) formatter.formatCellValue(row.getCell(idxRoom)).ifEmpty { "-" } else "-",
                        inventoryNumber = invVal.ifEmpty { "$mainVal-$subVal" },
                        lastInv = if (idxLastInv != -1) formatter.formatCellValue(row.getCell(idxLastInv)).ifEmpty { "-" } else "-"
                    )
                    workbook.close()
                    return result
                }
            }
            workbook.close()
        }
        return null
    }
}
